package io.ansor.al.huda.presentation.common

interface SelectionItemModel {
    val icon: Int
    val title: Int
}